// app/javascript/application.js

// 1. Fix require.context
if (typeof require !== "undefined" && typeof require.context === "undefined") {
  require.context = () => ({
    keys: () => [],
    resolve: () => "",
    (id) => ({ default: {} }),
  });
}

// 2. Import Turbo & Stimulus
import "@hotwired/turbo-rails";
import { Application } from "@hotwired/stimulus";
import "./controllers"; // your fixed controllers/index.js

// 3. Handle Turbo fetch headers globally
document.addEventListener("turbo:before-fetch-request", (event) => {
  event.detail.fetchOptions.headers = {
    ...event.detail.fetchOptions.headers,
    "X-CSRF-Token": document.querySelector("[name='csrf-token']")?.content,
    Accept: "text/vnd.turbo-stream.html, text/html, application/xhtml+xml",
  };
});

// 4. Handle Turbo fetch errors globally
document.addEventListener("turbo:fetch-request-error", (event) => {
  console.error("Turbo fetch error:", event.detail.error);
});

// 5. Fix Stimulus Map errors (optional safety)
if (typeof Map !== "undefined") {
  const originalMapGet = Map.prototype.get;
  Map.prototype.get = function (key) {
    try {
      return originalMapGet.call(this, key);
    } catch (e) {
      console.warn("Map get error ignored:", e);
      return undefined;
    }
  };
}
