// app/javascript/controllers/index.js
import { Application } from "@hotwired/stimulus";

// Start Stimulus app
const application = Application.start();

// Optional fallback for require.context (already in application.js)
if (typeof require !== "undefined" && typeof require.context === "undefined") {
  require.context = () => ({
    keys: () => [],
    resolve: () => "",
    (id) => ({ default: {} }),
  });
}

// Auto-import all controllers using modern ES modules
const controllerFiles = import.meta.glob("./**/*_controller.js", { eager: true });

Object.entries(controllerFiles).forEach(([path, module]) => {
  const controllerName = path
    .replace("./", "")
    .replace("_controller.js", "")
    .replace(/\//g, "--")
    .replace(/_/g, "-");

  application.register(controllerName, module.default);
});
