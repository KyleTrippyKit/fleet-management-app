class Store < ApplicationRecord
end
