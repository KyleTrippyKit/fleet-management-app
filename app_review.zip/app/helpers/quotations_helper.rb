module QuotationsHelper
end
