module Vmcott::VendorQuotationsHelper
end
