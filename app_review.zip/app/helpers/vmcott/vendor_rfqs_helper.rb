module Vmcott::VendorRfqsHelper
end
