# app/services/workflow_manager_complete.rb
class WorkflowManager
  attr_reader :inspection

  def initialize(inspection)
    @inspection = inspection
  end

  # PHASE 1: Vehicle Intake
  def intake_vehicle(params)
    @inspection.update!(
      client_type: params[:client_type],
      payment_terms: params[:payment_terms],
      status: :pending_inspection,
      received_at: Time.current,
      intake_photos: params[:photos],
      customer_signature: params[:signature],
      expected_pickup_date: params[:expected_pickup_date]
    )
    
    ReceptionLog.create!(
      vehicle: @inspection.vehicle,
      user_id: Current.user.id,
      driver_name: params[:driver_name] || params[:customer_name] || "Walk-in Customer",
      visitor_name: params[:visitor_name] || params[:customer_name] || params[:driver_name] || "Walk-in Customer",
      check_in_time: Time.current,
      condition_status: 'pending',
      portal_access_token: SecureRandom.hex(16),
      portal_access_expires_at: 7.days.from_now,
      customer_name: params[:customer_name],
      customer_phone: params[:customer_phone],
      customer_email: params[:customer_email]
    )
    
    @inspection
  end

  # PHASE 2: Inspection
  def perform_inspection(findings)
    if findings.blank?
      @inspection.update!(
        status: :ready_for_pickup,
        completed_at: Time.current,
        no_work_needed: true
      )
      return { status: 'no_work_needed', message: 'Vehicle inspection complete - no work required' }
    end
    
    findings.each do |finding|
      job = @inspection.inspection_jobs.create!(
        description: finding[:description],
        estimated_labor_cost: finding[:labor_cost],
        estimated_parts_cost: 0,
        status: :pending_mechanic_review,
        priority: finding[:priority] || 'normal'
      )
      
      @inspection.findings.create!(
        inspection_job: job,
        finding_type: 'initial',
        description: finding[:description],
        severity: finding[:severity],
        blocking: finding[:blocking] || false,
        created_by_id: Current.user.id
      )
    end
    
    @inspection.update!(status: :pending_mechanic_review)
    { status: 'needs_mechanic_review', jobs_count: @inspection.inspection_jobs.count }
  end

  # PHASE 3: Mechanic Review
  def mechanic_review(job_id, review_params)
    job = @inspection.inspection_jobs.find(job_id)
    
    job.update!(
      description: review_params[:description],
      estimated_labor_cost: review_params[:labor_cost],
      status: :pending_parts_review
    )
    
    if review_params[:parts_requested].present?
      review_params[:parts_requested].each do |part|
        PartsRequest.create!(
          inspection: @inspection,
          inspection_job: job,
          part: part[:part],
          quantity: part[:quantity],
          status: 'pending'
        )
      end
      job.update!(requires_part_approval: true)
    end
    
    if @inspection.inspection_jobs.where(status: :pending_mechanic_review).empty?
      @inspection.update!(status: :parts_coordinator_review)
    end
    
    job
  end

  # PHASE 4: Inventory Manager
  def process_parts_request(parts_request_id, action, params = {})
    parts_request = PartsRequest.find(parts_request_id)
    
    case action
    when :mark_in_stock
      parts_request.update!(
        status: 'in_stock',
        in_stock: true,
        processed_at: Time.current,
        processed_by: Current.user.id
      )
      
      job = parts_request.inspection_job
      if job.parts_requests.where.not(status: 'in_stock').empty?
        job.update!(parts_approved: true)
        
        if job.inspection.inspection_jobs.where(parts_approved: false).empty?
          job.inspection.update!(status: :pending_supervisor_review)
        end
      end
      
    when :send_to_procurement
      parts_request.update!(
        status: 'rfq_sent',  # This is a valid status from the enum
        sent_to_billing_at: Time.current
      )
      
      VendorRfq.create!(
        created_by_id: Current.user.id,
        rfq_number: "RFQ-#{Time.current.strftime('%Y%m%d')}-#{SecureRandom.hex(4).upcase}",
        processing_agency_id: @inspection.vehicle.agency_id,
        vehicle_id: @inspection.vehicle.id,
        status: 'draft',
        due_date: 7.days.from_now,
        notes: "Parts needed for inspection ##{@inspection.id}: #{parts_request.part.name}"
      )
      
      Notification.create!(
        title: "Part Delay Expected",
        message: "#{parts_request.part.name} needs to be ordered - est. 7 days",
        link: "/vmcott/inspections/#{@inspection.id}",
        user_id: User.where(role: "workshop_supervisor").first&.id
      )
    end
    
    parts_request
  end

  # PHASE 4.5: Supervisor Workflow Selection
  def supervisor_select_workflow(params)
    total_labor = @inspection.inspection_jobs.sum(:estimated_labor_cost)
    total_parts = @inspection.parts_requests.joins(:part).sum('parts.price * parts_requests.quantity')
    
    @inspection.update!(
      workflow_type: params[:workflow_type],
      labor_rate: params[:labor_rate],
      parts_markup_percentage: params[:parts_markup_percentage],
      total_estimated_cost: total_labor + total_parts,
      status: :pending_procurement_quotation
    )
    
    Notification.create!(
      title: "New quotation request",
      message: "Inspection ##{@inspection.id} needs quotation created",
      link: "/vmcott/procurement/new_quotation?inspection_id=#{@inspection.id}",
      user_id: User.where(role: "procurement").first&.id
    )
    
    @inspection
  end

  # PHASE 5: Create Quotation
  def create_quotation(params)
    quotation = Quotation.new(
      inspection: @inspection,
      vehicle: @inspection.vehicle,
      quote_number: generate_quote_number,
      version_number: 1,
      status: :draft,
      valid_from: Date.current,
      valid_to: 30.days.from_now,
      client_type: @inspection.client_type,
      payment_terms: @inspection.payment_terms,
      workflow_type: @inspection.workflow_type,
      created_by_id: Current.user.id
    )
    
    if @inspection.client_type == 'company'
      quotation.client = @inspection.vehicle.owner if @inspection.vehicle.owner.is_a?(Client)
    else
      quotation.agency = @inspection.vehicle.agency
    end
    
    @inspection.inspection_jobs.each do |job|
      q_job = quotation.quotation_jobs.build(
        job_template: job.job_template,
        name: job.description,
        description: job.description,
        estimated_hours: job.estimated_hours,
        labor_rate_per_hour: @inspection.labor_rate || 85.00,
        total_labor_cost: job.estimated_labor_cost
      )
      
      job.parts_requests.each do |part_request|
        q_job.quotation_job_parts.build(
          part: part_request.part,
          quantity: part_request.quantity,
          unit_price: part_request.part.price * (1 + (@inspection.parts_markup_percentage || 30) / 100.0),
          total_price: part_request.quantity * part_request.part.price * (1 + (@inspection.parts_markup_percentage || 30) / 100.0)
        )
      end
    end
    
    if quotation.save
      quotation.recalculate_amount!
      send_to_client_for_approval(quotation)
      quotation
    else
      nil
    end
  end

  # PHASE 6: Client Approval
  def client_approve_quotation(quotation, approved_items)
    if approved_items[:jobs].count == quotation.quotation_jobs.count
      quotation.update!(status: :accepted, accepted_at: Time.current)
      @inspection.update!(
        client_approval_status: 'full_approved',
        client_selected_jobs: approved_items[:jobs].map(&:to_s),
        status: :approved_for_repair
      )
      handle_payment_for_quotation(quotation)
    elsif approved_items[:jobs].any?
      new_quotation = create_quotation_version(quotation, approved_items[:jobs])
      quotation.update!(status: :superseded)
      new_quotation.update!(status: :accepted, accepted_at: Time.current)
      @inspection.update!(
        client_approval_status: 'partial_approved',
        client_selected_jobs: approved_items[:jobs].map(&:to_s),
        status: :approved_for_repair
      )
      handle_payment_for_quotation(new_quotation)
    else
      quotation.update!(status: :rejected, rejected_at: Time.current)
      @inspection.update!(
        client_approval_status: 'rejected',
        status: :on_hold,
        hold_reason: 'Customer rejected quotation',
        rejection_reason: params[:reason]
      )
      FollowUpReminderJob.set(wait: 3.days).perform_later(quotation.id)
    end
    
    Notification.create!(
      title: "Quotation #{quotation.status}",
      message: "Client has #{quotation.status} the quotation",
      link: "/vmcott/procurement/quotations/#{quotation.id}",
      user_id: User.where(role: "procurement").first&.id
    )
  end

  # PHASE 7: Job Execution
  def execute_job(job_id, action, params = {})
    job = @inspection.inspection_jobs.find(job_id)
    
    unless @inspection.job_approved?(job.id)
      return { error: 'Job not approved by client' }
    end
    
    if @inspection.needs_payment_before_work?
      return { error: 'Payment required before work can start' }
    end
    
    case action
    when :start
      unless job.can_start?
        return { error: 'Job cannot be started - dependencies not satisfied' }
      end
      job.start!
    when :pause
      job.pause!(params[:reason])
    when :block
      job.block!(params[:reason])
      if params[:requires_quote]
        create_additional_work_quotation(job, params[:reason])
      end
    when :add_finding
      finding = @inspection.findings.create!(
        inspection_job: job,
        finding_type: 'mechanic',
        description: params[:description],
        severity: params[:severity],
        blocking: false,
        created_by_id: Current.user.id
      )
      if params[:requires_approval]
        create_additional_work_quotation(job, params[:description])
      else
        job.update!(status: :in_progress)
      end
    when :complete
      job.complete!(params[:actual_labor_cost])
      if @inspection.inspection_jobs.where.not(status: :completed).empty?
        @inspection.update!(status: :ready_for_qc)
        notify_inspector_for_qc
      end
    end
    
    job
  end

  # PHASE 8: Quality Check
  def perform_qc(params)
    if params[:approved]
      @inspection.update!(
        status: :ready_for_pickup,
        qc_completed_at: Time.current,
        qc_inspector_id: Current.user.id,
        qc_notes: params[:notes],
        final_photos: params[:photos]
      )
      generate_final_invoice
      notify_client_ready_for_pickup
    else
      @inspection.require_rework!(params[:reason])
      @inspection.inspection_jobs.where(status: :completed).each do |job|
        job.request_rework!(params[:reason])
      end
      notify_mechanic_of_rework(params[:reason])
    end
  end

  # PHASE 9: Payment & Pickup
  def process_payment(payment_params)
    if payment_params[:paid_now]
      Payment.create!(
        inspection: @inspection,
        amount: payment_params[:amount],
        payment_method: payment_params[:method],
        transaction_id: payment_params[:transaction_id],
        status: 'completed',
        paid_at: Time.current
      )
      @inspection.update!(payment_status: 'paid', paid_at: Time.current)
      if @inspection.workflow_type == 'payment_before_work'
        start_approved_work(@inspection.approved_job_ids)
      end
    else
      @inspection.update!(
        payment_status: 'pending_pickup_payment',
        payment_due_at: @inspection.expected_pickup_date
      )
    end
    
    if @inspection.client_type == 'company'
      @inspection.update!(payment_status: 'on_account')
      add_to_monthly_statement(@inspection)
    end
  end

  def pickup_vehicle(params)
    if params[:pickup_code] == @inspection.pickup_code
      @inspection.record_pickup!(params[:picked_up_by])
      { success: true, message: "Vehicle released" }
    else
      { error: 'Invalid pickup code' }
    end
  end

  # PHASE 10: Additional Work
  def create_additional_work_quotation(job, description)
    additional_quotation = Quotation.new(
      inspection: @inspection,
      vehicle: @inspection.vehicle,
      quote_number: generate_quote_number,
      version_number: @inspection.quotations.count + 1,
      original_quotation_id: @inspection.quotations.last&.id,
      status: :draft,
      additional_work: true,
      created_by_id: Current.user.id
    )
    
    additional_quotation.quotation_jobs.build(
      name: "Additional: #{description.truncate(50)}",
      description: description,
      estimated_hours: job.estimated_hours * 0.5,
      labor_rate_per_hour: @inspection.labor_rate || 85.00,
      total_labor_cost: job.estimated_hours * 0.5 * (@inspection.labor_rate || 85.00),
      job_type: 'additional'
    )
    
    if additional_quotation.save
      send_to_client_for_approval(additional_quotation)
      additional_quotation
    end
  end

  private

  def generate_quote_number
    "Q-#{Date.current.year}-#{SecureRandom.hex(4).upcase}"
  end

  def send_to_client_for_approval(quotation)
    @inspection.update!(status: :awaiting_client_approval)
    
    if @inspection.client_type == 'walkin' && @inspection.reception_logs.last&.customer_email.present?
      QuotationMailer.quotation_ready(quotation).deliver_later if defined?(QuotationMailer)
    end
    
    Notification.create!(
      title: "Quotation Ready for Approval",
      message: "Quotation ##{quotation.quote_number} needs your approval",
      link: "/customer/quotation/#{quotation.id}",
      user_id: User.where(role: "client").first&.id
    )
  end

  def handle_payment_for_quotation(quotation)
    if @inspection.workflow_type == 'payment_before_work'
      @inspection.update!(payment_status: 'awaiting_payment')
      if @inspection.client_type == 'walkin'
        PaymentRequestMailer.payment_required(quotation).deliver_later if defined?(PaymentRequestMailer)
      end
    else
      start_approved_work(@inspection.approved_job_ids)
    end
  end

  def start_approved_work(job_ids)
    @inspection.inspection_jobs.where(id: job_ids).each do |job|
      job.update!(status: :pending_mechanic_work)
      Notification.create!(
        title: "New job ready",
        message: "Job: #{job.description} is ready to start",
        link: "/vmcott/mechanic/job/#{job.id}",
        user_id: User.where(role: "mechanic").first&.id
      )
    end
  end

  def create_quotation_version(original_quotation, approved_jobs)
  puts "DEBUG: Creating new quotation version with jobs: #{approved_jobs}"
  new_quotation = original_quotation.dup
  puts "DEBUG: Original quotation amount: #{original_quotation.amount}"
  new_quotation.quote_number = generate_quote_number
  new_quotation.version_number = original_quotation.version_number + 1
  new_quotation.original_quotation_id = original_quotation.id
  new_quotation.status = :draft
  new_quotation.amount = 0  # FIX: Initialize amount to 0 to avoid validation error
  new_quotation.save!
  
  # FIX: Handle both inspection job IDs and quotation job IDs
  # approved_jobs could be either inspection job IDs or quotation job IDs
  if approved_jobs.first.is_a?(Integer) && @inspection.inspection_jobs.exists?(approved_jobs.first)
    # If they're inspection job IDs, find corresponding quotation jobs
    approved_quotation_jobs = original_quotation.quotation_jobs.select do |q_job|
      approved_jobs.include?(q_job.inspection_job_id)
    end
  else
    # If they're quotation job IDs, use them directly
    approved_quotation_jobs = original_quotation.quotation_jobs.where(id: approved_jobs)
  end
  
  approved_quotation_jobs.each do |job|
    new_job = job.dup
    new_job.quotation_id = new_quotation.id
    new_job.save!
    
    job.quotation_job_parts.each do |part|
      new_part = part.dup
      new_part.quotation_job_id = new_job.id
      new_part.save!
    end
  end
  
  new_quotation.recalculate_amount!
  new_quotation.save!
  new_quotation
end

  def generate_final_invoice
    total_approved_cost = @inspection.total_approved_jobs_cost
    total_storage_fee = @inspection.total_storage_fee
    
    return unless total_approved_cost > 0
    
    Invoice.create!(
      inspection: @inspection,
      vehicle: @inspection.vehicle,
      amount: total_approved_cost + total_storage_fee,
      due_date: @inspection.payment_terms == 'net_30' ? 30.days.from_now : 7.days.from_now,
      status: 'pending',
      description: "Repair work for #{@inspection.vehicle.license_plate}"
    )
    
    if @inspection.client_type == 'company'
      add_to_monthly_statement(invoice)
    end
  end

  def notify_client_ready_for_pickup
    Notification.create!(
      title: "Vehicle ready for pickup",
      message: "Your vehicle #{@inspection.vehicle.license_plate} is ready. Pickup code: #{@inspection.pickup_code}",
      link: "/customer/dashboard",
      user_id: User.where(role: "client").first&.id
    )
  end

  def notify_mechanic_of_rework(reason)
    @inspection.inspection_jobs.where(status: :rework_needed).each do |job|
      Notification.create!(
        title: "Rework required",
        message: "Job ##{job.id} needs rework: #{reason}",
        link: "/vmcott/mechanic/job/#{job.id}",
        user_id: job.assigned_mechanic_id
      )
    end
  end

  def notify_inspector_for_qc
    Notification.create!(
      title: "QC required",
      message: "Inspection ##{@inspection.id} is ready for quality check",
      link: "/vmcott/inspector/qc/#{@inspection.id}",
      user_id: User.where(role: "inspector").first&.id
    )
  end

  def add_to_monthly_statement(invoice)
    monthly_statement = MonthlyStatement.find_or_create_by(
      vendor: invoice.client,
      period_start: Date.current.beginning_of_month,
      period_end: Date.current.end_of_month,
      status: 'draft'
    ) do |statement|
      statement.statement_number = "MS-#{Date.current.strftime('%Y%m')}-#{SecureRandom.hex(4).upcase}"
      statement.statement_date = Date.current
    end
    
    monthly_statement.line_items ||= []
    monthly_statement.line_items << {
      type: 'invoice',
      invoice_id: invoice.id,
      amount: invoice.amount,
      date: invoice.created_at,
      description: invoice.description
    }
    
    monthly_statement.total_invoices = monthly_statement.line_items.sum { |item| item[:amount] }
    monthly_statement.save!
  end
end
