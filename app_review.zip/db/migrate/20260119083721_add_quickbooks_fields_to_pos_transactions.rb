class AddQuickbooksFieldsToPosTransactions < ActiveRecord::Migration[8.1]
  def change
  end
end
