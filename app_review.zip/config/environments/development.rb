require "active_support/core_ext/integer/time"

Rails.application.configure do
  # Settings specified here will take precedence over those in config/application.rb.

  # Make code changes take effect immediately without server restart.
  config.enable_reloading = true

  # Do not eager load code on boot.
  config.eager_load = false

  # Show full error reports.
  config.consider_all_requests_local = true

  # Enable server timing.
  config.server_timing = true

  # Enable/disable Action Controller caching. By default Action Controller caching is disabled.
  # Run rails dev:cache to toggle Action Controller caching.
  if Rails.root.join("tmp/caching-dev.txt").exist?
    config.action_controller.perform_caching = true
    config.action_controller.enable_fragment_cache_logging = true
    config.public_file_server.headers = { "cache-control" => "public, max-age=#{2.days.to_i}" }
  else
    config.action_controller.perform_caching = false
  end

  # Change to :null_store to avoid any caching.
  config.cache_store = :memory_store

  # Store uploaded files on the local file system (see config/storage.yml for options).
  config.active_storage.service = :local
  
  # ============================================
  # ACTIVE STORAGE OPTIMIZATIONS FOR IMAGES
  # ============================================
  
  # Use VIPS for faster image processing (install libvips: sudo apt-get install libvips)
  config.active_storage.variant_processor = :vips
  
  # Cache variant URLs for better performance
  config.active_storage.service_urls_expire_in = 1.day
  
  # Queue variant processing to avoid blocking requests
  config.active_storage.queues.analysis = :low_priority
  config.active_storage.queues.purge = :low_priority
  config.active_storage.queues.transform = :low_priority
  
  # Increase variant cache size
  config.active_storage.routes_prefix = '/rails/active_storage'
  
  # ============================================
  # EMAIL CONFIGURATION - Using Mailtrap for Development
  # ============================================
  
  # Use async adapter for development (processes jobs in a background thread)
  # This prevents timeout issues and doesn't require additional services
  config.active_job.queue_adapter = :async
  
  # Mailtrap configuration for development (no authentication issues)
  config.action_mailer.delivery_method = :smtp
  config.action_mailer.perform_deliveries = true
  config.action_mailer.raise_delivery_errors = true
  config.action_mailer.default_options = { from: 'procurement@vmcott.com' }
  config.action_mailer.smtp_settings = {
    address: 'sandbox.smtp.mailtrap.io',
    port: 587,
    domain: 'vmcott.gov.tt',
    user_name: '00b0b0ddf3f1f1',
    password: 'd2f9abfa15fde1',
    authentication: 'plain',
    enable_starttls_auto: true,
    open_timeout: 30,
    read_timeout: 30
  }
  config.action_mailer.default_url_options = { 
    host: 'localhost', 
    port: 3000,
    protocol: 'http'
  }

  # Make template changes take effect immediately.
  config.action_mailer.perform_caching = false

  # Print deprecation notices to the Rails logger.
  config.active_support.deprecation = :log

  # Raise an error on page load if there are pending migrations.
  config.active_record.migration_error = :page_load

  # Highlight code that triggered database queries in logs.
  config.active_record.verbose_query_logs = true

  # Append comments with runtime information tags to SQL queries in logs.
  config.active_record.query_log_tags_enabled = true

  # Highlight code that enqueued background job in logs.
  config.active_job.verbose_enqueue_logs = true

  # Highlight code that triggered redirect in logs.
  config.action_dispatch.verbose_redirect_logs = true

  # ============================================
  # ASSET PIPELINE OPTIMIZATIONS
  # ============================================
  
  # Disable debug mode for faster compilation
  config.assets.debug = false
  
  # Enable asset compilation on the fly
  config.assets.compile = true
  
  # Increase asset digest length for better caching
  config.assets.digest = true
  
  # Precompile additional assets
  config.assets.precompile += %w( application.js application.css )
  
  # Suppress logger output for asset requests.
  config.assets.quiet = true

  # Raises error for missing translations.
  # config.i18n.raise_on_missing_translations = true

  # ============================================
  # VIEW CACHING FIX - Prevents "undefined method 'updated?' for nil" error
  # ============================================
  
  # Disable view template caching to prevent nil errors in development
  config.action_view.cache_template_loading = false
  
  # Set to false to avoid file watching issues
  config.action_view.annotate_rendered_view_with_filenames = false
  
  # Uncomment if you wish to allow Action Cable access from any origin.
  # config.action_cable.disable_request_forgery_protection = true

  # Raise error when a before_action's only/except options reference missing actions.
  config.action_controller.raise_on_missing_callback_actions = true

  # Apply autocorrection by RuboCop to files generated by `bin/rails generate`.
  # config.generators.apply_rubocop_autocorrect_after_generate!
  
  # ============================================
  # ADDITIONAL PERFORMANCE OPTIMIZATIONS
  # ============================================
  
  # Increase maximum concurrent connections
  config.middleware.use Rack::Deflater
  
  # Enable HTTP/2 if available
  config.force_ssl = false  # Disable in development for faster testing
  
  # Log level
  config.log_level = :debug
  
  # ============================================
  # CACHE PREVENTION FOR DEVELOPMENT - FIXES BLANK PAGE ON RELOAD
  # ============================================
  
  # Disable all caching to prevent blank pages on reload
  config.public_file_server.enabled = true
  config.public_file_server.headers = {
    'Cache-Control' => 'no-cache, no-store, must-revalidate',
    'Pragma' => 'no-cache',
    'Expires' => '0'
  }
  
  # Disable asset caching
  config.assets.debug = true
  config.assets.compile = true
  config.assets.digest = false
  
  # Disable view cache
  config.action_view.cache_template_loading = false
  
  # Disable action controller caching
  config.action_controller.perform_caching = false
end